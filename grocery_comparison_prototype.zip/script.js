function searchProduct() {
    let product = document.getElementById("searchBox").value.toLowerCase();
    let results = document.getElementById("results");
    let data = {
        "milk": {
            "Blinkit": { "price": "$2.50", "link": "https://www.blinkit.com" },
            "Zepto": { "price": "$2.40", "link": "https://www.zepto.com" },
            "Swiggy Instamart": { "price": "$2.45", "link": "https://www.swiggy.com" }
        },
        "bread": {
            "Blinkit": { "price": "$1.50", "link": "https://www.blinkit.com" },
            "Zepto": { "price": "$1.40", "link": "https://www.zepto.com" },
            "Swiggy Instamart": { "price": "$1.45", "link": "https://www.swiggy.com" }
        }
    };
    
    if (data[product]) {
        results.innerHTML = "";
        for (let platform in data[product]) {
            let row = `<tr>
                <td>${platform}</td>
                <td>${data[product][platform].price}</td>
                <td><a href="${data[product][platform].link}" target="_blank">Go to Store</a></td>
            </tr>`;
            results.innerHTML += row;
        }
    } else {
        results.innerHTML = "<tr><td colspan='3'>No data available for this product</td></tr>";
    }
}
